Oihukatzen hasi zara eta pertsona arraroak gaztainak botatzen hasi da zure harresiaren kontra. 

Gaztainak leherketa handiak egiten dituzte eta zeure gastelua apurtzen hasten da.