Zure gazteluan zaudela, pertsona arraro bat hurbiltzen da harresira, gaztainak saltzen dituela esanez.

Zer egingo duzu?

[Pertsona arraroari alde egiteko esan.](alde-egin/alde-egin.md)

[Gaztelura sartzen utzi eta dozena bat gaztaina erosi.](erosi/erosi.md)

[Kasurik ez egin eta gaztelura sartu.](gaztelura-sartu/gaztelura-sartu.md)
