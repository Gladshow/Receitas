Zure gaztelura sartu eta bideojoko batekin jolasean hasten zara.
