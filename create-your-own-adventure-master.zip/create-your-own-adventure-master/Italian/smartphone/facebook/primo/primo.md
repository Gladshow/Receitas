Ciao, scusa se ti disturbo, ma ti ricordi di me?

Caspita, ma tutti a me mi dovete capitare? Soltanto perché il mio nome comincia per A ed è il primo della lista 
vi sentite autorizzati a rompermi le scatole?
Si può sapere chi sei, e soprattutto che vuoi da me?

Chi sono? Bella domanda... in realtà io mi stavo chiedendo dove sono, ma ora che mi ci fai pensare, non mi ricordo 
nemmeno chi sono!!!
