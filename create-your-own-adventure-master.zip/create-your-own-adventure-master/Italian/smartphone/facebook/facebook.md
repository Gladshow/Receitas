Accidenti!
Ho un milione di amici ma non riconosco nessuno.

La situazione non è delle più rosee, ma devi pur far qualcosa, quindi decidi di

contattare [un amico a caso](qualsiasi/qualsiasi.md)

contattare [il primo amico nella lista](primo/primo.md)
