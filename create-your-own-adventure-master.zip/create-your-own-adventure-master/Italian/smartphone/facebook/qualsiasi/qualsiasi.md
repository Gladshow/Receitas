Ciao, scusami se ti disturbo, ma ti ricordi di me?

Certo che sì, e l'ultima volta che ci siamo parlati, mi pare di averti detto di non volerti più
vedere nemmeno in fotografia! 
Si può sapere che vuoi ancora?

Ehm, scusami, devo aver perduto la memoria... nemmeno mi ricordo di te... comunque sono nei guai 
e avrei bisogno d'aiuto...
