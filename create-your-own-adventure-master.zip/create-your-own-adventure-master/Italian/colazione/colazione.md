[Si mangia](https://www.youtube.com/watch?v=sN6opoE0iZk)

Si esce a prendere il tram

[prendi dei sonniferi] (../domire/sogno-strano.md)