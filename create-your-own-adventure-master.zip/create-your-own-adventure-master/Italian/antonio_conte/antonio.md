TELEFONATA AD ANTONIO CONTE (A.C.)

Io: We, Mister! Come andiamo? Mi sono svegliato in una
[stanza molto strana](http://giphy.com/gifs/uy4zM12rn3oaY).
Che cosa devo fare?

A.C.: Esci, esci - meglio cosi!
[immagine di supporto](http://giphy.com/gifs/sporzaredactie-euro2016-italia-sporza-26BoCA9sGwKqelZra)

Io: Ma mister, sembra ci siano
[belle ragazze](http://giphy.com/gifs/dancing-dance-SioZIrQsuN36E)...

A.C.: ... [clicca qui va'...](http://giphy.com/gifs/sporzaredactie-euro2016-italia-sporza-l41YiaHYCcSwrZGBq)