Allungo la mano alla ricerca di un interruttore.
