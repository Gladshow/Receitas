Stringi i denti e cerchi di resistere al dolore. Tu sei forte. Puoi farcela.
Cosa vuoi che sia una piccola ferita? Hai passato di peggio. Ehi, sanguina 
sempre di più. Non si ferma. Aiuto. Panico.

[Inizi ad andare nel panico e ti butti a terra piangendo] (../piangi/piangi.md)

[Resisti ancora] (resisti-ancora/resisti-ancora.md)
