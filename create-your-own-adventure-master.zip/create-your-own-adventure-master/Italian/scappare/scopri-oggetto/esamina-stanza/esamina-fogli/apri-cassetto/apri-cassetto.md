Inserisci l'oggetto triangolare nella fessura del cassetto, che si apre.
