La stanza intorno a te ha pareti di pietra che ricordano quelle di un antico castello.
Vicino al letto noti una scrivania di legno con alcuni fogli sparsi su di essa.

[Esamini i fogli sulla scrivania](esamina-fogli/esamina-fogli.md)

[Osservi il resto della stanza](controlla-stanza/controlla-stanza.md)
