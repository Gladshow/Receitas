Ti alzi per cercare una via d'uscita.
Inciampi in una bottiglia rotta a metà, e ci sono vetri ovunque.

[La raccogli](raccogli/raccogli.md)

[Cerchi una scopa](cerca/cerca-scopa.md)

[Ti arrabbi perchè il tappeto è sporco](arrabbi/arrabbi.md)

[Approfitti del vetro più tagliente per farti la barba](barba/barba.md)

[Fra i vetri rotti scopri un oggetto](scopri-oggetto/scopri-oggetto.md)

[Provi a ripararla] (riparare/ripari.md)