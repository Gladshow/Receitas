La tua indole da Bob-Aggiustatutto ti porta a cercare di riparare la bottiglia.
