Ti arrabbi e urli pensando a qualche persona maldestra che ha fatto cadere la bottiglia.
 