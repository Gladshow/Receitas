Non importano le circostanze, per te rimanere impeccabile anche nelle situazioni più avverse è fondamentale.

Ma senza dopobarba non è piacevole.
