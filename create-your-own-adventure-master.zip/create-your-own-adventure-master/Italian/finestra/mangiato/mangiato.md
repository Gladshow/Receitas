Mentre fai la foto ti accorgi che il Tirannosauro si muove nella tua direzione

Non fai tempo a spostarti e il tirannosauro ti mangia in un sol boccone!

Per tua fortuna il Tirannosauro, frutto di un esperimento del Jurassic Park™,

è erbivoro. Quando si accorge della presenza di carne umana nella sua bocca,

ti sputa contro un tronco.

