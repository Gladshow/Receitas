Corri a più non posso e raggiungi il tappeto volante appena in tempo...

Il tappeto si alza in volo

[Ti dirigi sopra il T-Rex](sopra-t-rex/sopra-t-rex.md)