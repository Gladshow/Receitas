Ti stai calando dalla finestra, quando la fune si spezza e precipiti nel vuoto

Per fortuna sotto di te si trova un gigantesco Marshmellow che attutisce la tua caduta

Ma attento perch� il Tirannosauro si sta avvicinando!

[Crei una bambola voodoo per addomesticarlo](../tour/tour.md)

[Corri verso il tappeto volante](tappeto-volante/tappeto-volante.md)
