Ma siamo sicuri di aver voglia di lavorare ?
[O è meglio cazzeggiare ?](cazzeggiare/cazzeggiare.md)
