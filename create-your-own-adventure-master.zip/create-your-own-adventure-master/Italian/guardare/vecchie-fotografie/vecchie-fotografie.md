Le fotografie hanno uno scaffale a loro riservato, e la maggiorparte è stata messa con cura all'interno di cornici
d'argento.

Sembrano fotografie scattate negli anni 50, almeno a giudicare dall'abbigliamento di coloro che vi sono ritratti.

Vi sono uomini e donne di diversa età, e in alcune immagini, inspiegabilmente, vi sono delle bruciature sul viso 
di alcune persone.

Ti chied chi siano queste persone e cosa c'entrino con la strana avventura che stai vivendo. Per scoprirlo puoi:

[Girare le fotografie per vedere se c'è scritto un messaggio] (girare_foto/messaggio.md)

[cercare aiuto nei libri presenti sulla biblioteca] (../libri-francesi/libri-francesi.md)

[esci dalla stanza per cercare aiuto] (uscita_stanza/uscita_stanza.md)
