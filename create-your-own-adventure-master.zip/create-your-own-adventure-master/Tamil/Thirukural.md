﻿முகநக நட்பது நட்பன்று நெஞ்சத்து அகநக நட்பது நட்பு
Face's smile doesn't shows the friendship, but the heart's rejoice does.

உடுக்கை இழந்தவன் கைபோல ஆங்கே 
இடுக்கண் களைவதாம் நட்பு
Friendship hastens to rescue as fast as hand’s reflex to catch slipping cloth

தெய்வத்தான் ஆகா தெனினும் முயற்சிதன்
மெய்வருத்தக் கூலி தரும்
Though fate-divine should make your labour vain;
Effort its labour's sure reward will gain