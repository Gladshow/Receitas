தமிழ் :
மாசில் வீணையும் மாலை மதியமும்
வீசு தென்றலும் வீங்கிள வெய்னிலும்
மூசு வண்டறைல் பொய்கயும் போன்றதே
ஈசன் எந்தை இணையடி நீழலே

English:
Maasil Veenaiyum Maalai Madhiyamum
Veesu thendralum veengila veynilum
Moosu vandarai poygayum ponradhee
Eesan endhai inayadi neezhalee.

Meaning:
The shelter under the parallel feet of the God, my boss,
is like the nice melody of Veena (Musical Instrument), the early evening moon,
pleasant breeze, the Spring, a pond where bees are in making sound.
