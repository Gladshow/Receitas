Tja wat moet je nu met een sleutel... Nu ja, je zit geen andere mogelijkheid dan
toch het kledingstuk waaraan je hangt langzaam kapot te schuren met de sleutel.

Geheel verdiept in het schuren en scheuren merk je pas langzaam op dat...

...dit helemaal jouw sleutels niet zijn. Wat was er toch gebeurd deze [nacht]?(nacht/deze-nacht.md)

...dit magische sleutels zijn, niet van deze [wereld](wereld/welkeWereld.md)
