Plotseling komen vage beelden naar boven ...

Je beseft dat je droomt, alsof je in een slecht verhaal zit, en ziet dat alles verkeerd gespeld is. 
Een boom heet plotseling booom en benzinetankstation heet bedritanktontiats. 

Maar zoals in alle dromen die van zichzelf bewust zijn 
heb je de keuze om [wakker te worden](../../../welkom.md).

Of toch maar lekker [verder droooomen](../../../droom/droom.md).