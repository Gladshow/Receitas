Het zakmes bevat een ijzerzaag. Die is nog flijmscherp want je hebt hem nog nooit gebruikt. 

Je probeert jezelf los te zagen, maar dit heeft geen effect wat je zit vastgeplakt aan het hek. 

Als zelfs een zaag niet helpt... Je overweegt je opties.

- Dan maar de hulplijn bellen. Je reikt naar [de mobiele telefoon](../mobiel/mobiel.md) die je eerder had gevonden.

- Je bedenkt wat je met [een flippo](../flippo/flippo.md) zou kunnen doen.
