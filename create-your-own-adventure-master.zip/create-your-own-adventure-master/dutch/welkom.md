... en doe ze de groeten thuis ...

Na een zware kroegentocht met Uw vrienden, loopt U nu eenzaam ergens midden op de hei.
In de verre omtrek is er ook geen kip te zien. Van Uw vrienden is er ook niemand te bespeuren,

U denkt

... lekker rustig, eindelijk geen gezeur van de baas. Hier blijf ik een poosje.

... in het [bos](bos/donker-bos.md) daarginds is het vast koeler.

... niet naar het bos! U heeft het gevoel dat daar iets niet pluis is... 
    u keert uw rug naar het bos en nu ziet u een hek. Daar [klimt u overheen](over-het-hek/hek.md).

... of u kijkt even op uw iphone of u een [mailtje heeft](check-mail/mail.md)

... u hoort uw iphone een geluidje maken en kijkt het is een sms [sm](sms/sms.md)

... maar de Iphone heeft weer geen batterij want deze gaat snel op. 
Dus pak je maar je android die wel drie dagen lang meegaat!



[Google translate NL](https://translate.google.com/#nl/en/)

Terug naar [taalkeuze](../language.md)
