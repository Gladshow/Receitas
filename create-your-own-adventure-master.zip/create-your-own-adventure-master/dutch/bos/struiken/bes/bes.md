Je krijgt een visioen.

Je bevindt je in de [struiken](../in_de_struiken.md).