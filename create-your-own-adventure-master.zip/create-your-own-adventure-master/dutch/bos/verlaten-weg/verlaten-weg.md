Er is niemand op de weg te zien, je blijft een tijdje wachten,
in de hoop dat je iemand tegenkomt.  

Uiteindelijk besluit je dan maar in een bepaalde richting te wandelen ...