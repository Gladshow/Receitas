Terwijl je rent zie je dat de mannen afremmen en angstig jouw kant op kijken.
Vervolgens draaien ze zich om en rennen van je af. Terwijl je je afvraagt waarom ze dat zouden doen,
gebeurt er het volgende: