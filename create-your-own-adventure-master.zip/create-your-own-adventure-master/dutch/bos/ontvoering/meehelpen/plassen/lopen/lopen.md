Je begint te rennen en kijkt na 50 meter om, je ziet de zware jongens achter je aan rennen.
Wat doe je?

Je laat je op de grond vallen en doet alsof je dood bent.

Je klimt in een boom.

Je stopt, [draait je om](omdraaien/terugrennen.md) en rent zo hard als je kan op de zware jongens af.

Je maakt een scherpe bocht, de zware jongens merken het niet op, maar je glijdt
uit en [rolt](vastzitten/vastzitten.md) van een heuvel af.
