Zodra je de bosjes bereikt hebt...

Zet je het op een [lopen](lopen/lopen.md).

Uit het zicht pak je je [mobiel](mobiel/mobiel.md) om 112 te bellen.

Je bedenkt je en doet net alsof je [plast](plast/plast.md).