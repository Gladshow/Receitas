Ik denk niet dat ik nu een keuze kan maken, wie het wordt. 
Maar ik weet wel dat de sterkste van jullie twee de grootste kans maakt om met mij samen te werken. 

Ik ben namelijk benieuwd wie van jullie....