In eerste instantie geloven de mannen je niet maar als ze je Rolex om je arm
zien zijn ze snel geïnteresseerd. Wie is deze man?

De mannen kijken elkaar aan en na een korte blik vraagt de langste man:
Voor wie werk jij dan eigenlijk en heb je nog meer klussen?

- Ik ben Lucien de zoon van Carmen van Walraven en ik kom [wraak nemen!](wraak/wraak.md)

- Ik ben Ruben de Roker...
leider van de grootste mensensmokkerlaarsbende van Nederland
en ik heb nog [een mooie klus voor één van jullie.](mensensmokkel/mensensmokkel.md)