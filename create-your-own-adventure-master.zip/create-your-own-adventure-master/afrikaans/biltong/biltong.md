Tensy jy meer van 'n soet tand het, het jy die beste opsie gekies.

In jou hart is jy 'n ware Suid Afrikaner.