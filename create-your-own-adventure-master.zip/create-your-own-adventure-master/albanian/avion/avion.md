Udhetime me avion eshte i shpejte, por kushton me shume se sa buxheti juaj. 

Prisni te keni fonde te mjaftueshme?

Apo konsideroni [menyra te tjera udhetimi](../hyrje.md).