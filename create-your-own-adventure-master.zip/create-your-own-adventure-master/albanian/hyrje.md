Nje dite prej ditesh, ti vendos te nisesh per nje udhetim.

Udheton me [avion](avion/avion.md)?

Udheton me [tren](tren/tren.md)?

Apo udheton me ndonje menyre tjeter?