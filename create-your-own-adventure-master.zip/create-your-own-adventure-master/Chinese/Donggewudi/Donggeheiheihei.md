孙悟空变成了东哥，就此解放了压抑数百年的欲望，看见石头就想嘿嘿嘿

直到有一天，被宠幸的石头开口说话：

[你可知月光宝盒？](../Xinyang/MyLoveStory.md)

由此嘿嘿嘿

东哥也很喜欢操[大白](../Baymax/Baymax.md)

若你對嘿嘿嘿好奇，請點[這裡](https://youtu.be/_7-e7DsUgUs)  
