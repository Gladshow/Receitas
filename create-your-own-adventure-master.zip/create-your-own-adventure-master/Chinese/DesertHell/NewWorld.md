This is a new world
"新的世界“
Let’s start from beginning
end
一个白胡子老头正在讲故事，
[他讲的什么？](./OldStory/Story.md)

[我不想听，继续往前走。](./Walk/Walk.md)

[老头突然念起了李白的将进酒](./Jiangjinjiu/Jiangjinjiu.md)