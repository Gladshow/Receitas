500年后孙悟空变成了葫芦娃的水娃，哈，然后
他突然[干什么呢？](./newstory/newstory.md)