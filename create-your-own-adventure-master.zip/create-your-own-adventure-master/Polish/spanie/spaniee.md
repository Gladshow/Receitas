Po obudzeniu się sytuacja się  nie zmieniła!

Co robisz?

[Start](../ptasieMleczko.md)

[Idziesz dalej spać](./spaniee.md)
