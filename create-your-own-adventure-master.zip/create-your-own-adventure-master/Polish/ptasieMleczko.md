Pewnego ranka obudziłeś się w dziwnym pokoju ze ścianami z ptaskiego mleczka.

Okazało się również, że masz na sobie niewygodną kurtkę i nie masz na sobie spodni...

Czujesz, �e wzmaga si� w tobie pragnienie, czy to nie jest dobry pomys�, �eby napi� si� Kadarki?

Co robisz? 

[Idziesz spac?](spanie/spaniee.md)

[Czujesz zew przygody](przygoda/przygoda.md)

[Chcesz się przebrać](ubranie/ubranie.md)

[Idziesz kupi� Kadark�](kadarka/kadarka.md)
i
