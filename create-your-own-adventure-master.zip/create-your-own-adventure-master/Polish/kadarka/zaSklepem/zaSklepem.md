Tak jak myślałemś, impreza za sklepem to lepszy pomysł. 
Od teraz Ziutek i Mietek określają Cię mianem "BOSS". ;))

Po wielkiej imprezie Ziutek, Mietek i Ty macie wilekiego kaca.
Całe szczęście Ty wiesz co trzeba zrobić.
Z wielkim wysiłkiem podnosisz się z ziemi i przeszukujesz kieszenie.
Jest. Tak. Masz to!
Wiesz, że to co teraz nastąpi będzie trudne. Dla nich musisz się poświęcić.
Najpierw lewa potem prawa, lewa, prawa, lewa, prawa. 
Całe szczęście to nie jedna z tych imprez gdzie przypominasz sobie jak się chodzi po trzech dniach.
Cztery potknięcia, jedna gleba i 3 ulice dalej jest ona. Biedronka.
Wchodzisz i z zamkniętymi oczami, niemal mechanicznie trafiasz pod odpowiedni regał, a ręka sama zaciska się na szyjce.
W kasie rzucasz ledwo spoglądając na kasjerkę odliczoną kwotę, którą znalazłeś w kieszeni.
Z większym powodzniem wracasz do kompanów. Ziutek już siedzi, a Mietek nawet wstał oddać mocz.
Kiedy widzą, że w ręku trzymasz lekarstwo na tę straszną dolegliwość, która was z rana dopadła oczy zachodzą im łzami. 
W geście triumfu podnosisz Amarenę!