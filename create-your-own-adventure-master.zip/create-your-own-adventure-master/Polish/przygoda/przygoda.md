Zew przygody wzywa cię. Czujesz, że musisz się wydostać z tego pokoju. 
Rozglądasz się po pokoju w poszukiwaniu wyjścia. Jednak wyjścia nie ma.

Co robisz?

[Rozbijasz ściany siłą woli](wola/wola.md)

[Rozbijasz ściany siłą mięśni](miesnie/miesnie.md)

[Zaczynasz jeść ptasie mleczko](jedzenie/jedzenie.md)

[Szukasz rozwiązania u wujka Google](http://www.google.pl)
