Poczułeś nagły, przeszywający ból w okolicach kości potylicznej, 
a na twoich pośladkach pojawiły się bolące wrzody.
Uświadomiłeś sobie właśnie, że przez twój śmieszkizm twój poziom RIGCZu spadł do poziomu 
Szumlewicza absolutnego, co wywołało u ciebie raka i ból dupy. 
Umierasz. 
