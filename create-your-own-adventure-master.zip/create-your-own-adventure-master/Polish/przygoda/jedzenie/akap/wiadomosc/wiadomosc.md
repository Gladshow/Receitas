Odsłuchałeś właśnie Ważną Wiadomość.

Co dalej? 

[Stosujesz się do Ważnej Wiadomości](odsluch/odsluch.md)

Masz Ważną Wiadomość w dupie 
