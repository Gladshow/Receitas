Siedzisz właśnie w swojej piwnicy, która od niepamiętnych czasów jest twoim domem. 
Mieszkasz tu odkąd twoi rodzice wyrzucili cię z domu, 
gdy dowiedzieli się ze jesteś libertarianinem. 
Siedzisz na stołku i z opartymi łokciami 
o biurko spoglądasz na monitor swojego komputera. 
Lurkujesz właśnie swoją ulubioną grupę na Facebooku 
"Jak będzie w akapie" chichocząc się pod nosem ze śmieszkowych postów

Wtem nagle zza twoich pleców dobiegało głośne pukanie do drzwi. 
Z lekkim niepokojem spoglądasz za siebie, 
obserwując wrota do twojego królestwa.

Przecież mama dziś już raz przynosiła mi kanapki - 
Przypomniałeś sobie, jednocześnie zdając sobie sprawy że nie masz kolegów, dziewczyny 
a całe twoje życie towarzyskie ogranicza się tylko do pewnej grupy na Facebooku.

Co robisz?

Jeśli uważasz, że to rynek ma podjąć za ciebie decyzję, 
to zapraszam [tutaj.](rynek/rynek.md)

Jeśli uważasz, że otwieranie drzwi nieznajomym to doskonały pomysł, 
to [zrób to śmiało.](drzwi/drzwi.md)

Jeśli ciekawi cię, kto śmiał zakłócić twój bój o wolność i własność w internetach, 
to [zapytaj kto tam.](kto-tam/kto-tam.md)

Oczywiście, zawsze możesz odsłuchać [ważną wiadomość.](wiadomosc/wiadomosc.md)
