Teleportujesz się na skwer przed ulubioną księgarnią 
komputerową skrywającą staroświeckie papierowe woluminy 
wszechwiedzy. Skwer jest rozgrzany popołudniowym słońcem 
lipcowego skwaru. Twój wzrok automatycznie kieruje się ku 
nogom dwóch przechodzących dziewcząt. Kobiety mijają cię, 
a ty odwracasz się za nimi. Podnosisz wzrok w kierunku 
kołyszących się pup. Odpędzasz od siebie nieczyste myśli, 
odwracasz się na pięcie i wchodzisz się do księgarni. 

Sprzedawca, cybernetyczny, zasuszony hipernerd wita cię tymi 
słowami:


[Lubię placki! Masz ochotę na placka?] (placki/placki.md)

[Razem zmienimy Polskę!] (polska/polska.md)

[Popuś to Ty?] (popus/popus.md)