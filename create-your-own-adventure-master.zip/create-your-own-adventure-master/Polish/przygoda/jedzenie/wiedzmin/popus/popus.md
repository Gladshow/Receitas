Nagle jak przy porodzie z pizdy wyskakuje Alibaba, a za nim biegnie Popus krzyczac
"Szehrem ehrem ergu myszke, turbany z gl�w!". Przygladasz sie tej scenie spokojnie: