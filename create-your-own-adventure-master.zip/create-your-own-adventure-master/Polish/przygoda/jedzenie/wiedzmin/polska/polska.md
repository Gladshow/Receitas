Uradowany podskakujesz z radosci i razem idziecie na wybory zaglosowac na Kukiza.
W glebi duszy wiesz, ze to jedyny sluszny wybor w dzisiejszych czasach.