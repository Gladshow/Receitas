Zaczynasz pisac biznes plan i caly czas wciagasz ogromne ilosci mleczka.
Chcesz zeby biznesplan byl dopracowany, piszesz go caly miesiac.
Umierasz na cukrzyce.