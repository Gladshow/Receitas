Chcesz wykorzystać potencjał ptasiego mleczka i jeszcze na tym zarobić. Zabierasz się za biznesplan! Co robisz?

[Zaczynasz pisać i pisać...](cukrzyca/cukrzyca.md)

[Wstrzymujesz pisanie i szukasz klientow na mleczko](podlakorp/podlakorp.md)
