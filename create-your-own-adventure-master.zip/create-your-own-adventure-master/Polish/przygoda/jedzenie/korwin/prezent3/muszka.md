Korwin szaleje z radosci i mianuje ci� premierem
