Korwin jest wielce zadowolony z Twojego prezentu, dlatego
zabiera Cię na wspólne polowanie na czerwonych.