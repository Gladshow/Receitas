Idziesz głosować na Korwina. W krainie Polonii już na zawsze zapanuje lekkie gwałcenie i wolny rynek.
Wygrałeś

Niedługo koronacja Korwina na krula wszechświata.
Jaki prezent podarujesz swojemu monarsze?

[Złoty rewolwer](prezent/rewolwer.md)

[Złoty krawat](prezent2/krawat.md)

[Zlota muszke](prezent3/muszka.md)
