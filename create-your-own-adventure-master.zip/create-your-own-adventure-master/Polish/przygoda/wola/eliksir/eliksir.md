Wypiłeś tyle eliksiru woli, że spojrzeniem zmiotłeś czasoprzestrzeń. 
Wśród kompletnej pustki dostrzegasz tunel, który przenosi cię w czasie. 
Jesteś w przyszłości w której ludzie zapomnieli o Johnie Travolcie w "Gorączce Sobotniej Nocy". 

Tak ci go żal, że umierasz.