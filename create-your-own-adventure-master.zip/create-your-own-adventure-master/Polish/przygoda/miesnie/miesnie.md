Siłujesz się ze ścianami przez kilka godzin, aż w końcu opadasz z sił.

Co robisz?

[Rozbijasz ściany siłą woli](../wola/wola.md)

[Zaczynasz jeść ptasie mleczko](../jedzenie/jedzenie.md)

[Kładziesz się na podłodze i zasypiasz](./spanie/spanie.md)

[W rogu pudełka zauważasz leżące zapałki](./zapalki/zapalki.md)
