Budzisz się z okropnym bólem głowy. Z przerażeniem stwierdzasz, że nie możesz poruszyć nogami ani rękami.
