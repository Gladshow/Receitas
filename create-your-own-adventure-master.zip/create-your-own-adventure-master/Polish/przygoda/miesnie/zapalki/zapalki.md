Podchodzisz bliżej i nie wierzysz własnym oczom.
Ktoś rzeczywiście zostawił tu zapałki! Co z nimi zrobisz?

[W końcu ignorujesz je. Nie jesteś zbyt bystrą osobą.](../../przygoda.md)
