Idziecie ze skunksem na pizze, a później do baru na piwo.
