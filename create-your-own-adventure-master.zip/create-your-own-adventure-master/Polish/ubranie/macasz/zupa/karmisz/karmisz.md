Skunks, początkowo podejrzliwy i nieufny, podchodzi zwabiony cypryjskim przysmakiem i bierze do pyska pierwszy brokuł.
Wykrzywia pyszczek i mówi: "To mi przypomina czasy szkolnej stołówki, chodźmy
lepiej na pizze albo sami coś ugtujmy."

[Idziesz](idziesz/idziesz.md) ze skunksem na pizze.

[Gotujesz](gotujesz/gotujesz.md) ze skunksem kumpla, który wyżera właśnie brokuły.
