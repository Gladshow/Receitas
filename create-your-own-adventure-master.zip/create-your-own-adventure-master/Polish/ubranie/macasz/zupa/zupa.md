Otwierasz kieszeń. Tak to brokuły. 
Nagle przenosisz się do przedszkolnej stołówki, a przed tobą stoi talerz pełen pożywnej zupy brokułowej bez soli.
Twoją uwagę zwraca stojący obok stolika, stary i mokry skunks, który wpatruje się w talerz z obiadem.

[Karmisz](karmisz/karmisz.md) go zupą w nadziei, że uwolni cię od brokułowego koszmaru.

[Moczysz](moczysz/moczysz.md) skunksa w zupie kumpla, który właśnie wyszedł do toalety.
