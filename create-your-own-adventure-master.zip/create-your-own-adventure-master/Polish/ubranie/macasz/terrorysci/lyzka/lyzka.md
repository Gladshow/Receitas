Oko bandyty by�o pod��czone do detonatora i bomby umieszczonej w jego odb-, hmm, z ty�u.
Bomba wybucha i rozrywa cie na kawa�ki.

Koniec.