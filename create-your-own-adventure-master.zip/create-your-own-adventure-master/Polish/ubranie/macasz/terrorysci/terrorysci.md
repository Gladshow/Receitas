Otwierasz kieszeń. Niestety jest tak jak myślałeś, to kalafior. 
Nagle przenosisz się do przedszkola opanowanego przez niebezpieczną grupę kalafiorowych terrorystów.
Bandyci nie mają broni palnej, posługują się wyimaginowanymi pistoletami stworzonymi z palca i kciuka.
Jeden z nich podchodzi do ciebie i celuje w twoją głowę.

[Wbijasz mu łyżkę w oko](lyzka/lyzka.md)

[Zsikujesz się ze strachu](siku/siku.md)