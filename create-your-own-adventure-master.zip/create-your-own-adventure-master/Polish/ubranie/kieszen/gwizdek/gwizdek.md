Probujesz zagwizdać, lecz nie wydobywasz z gwizdka żadnego dźwięku. Nie słyszysz nawet wydychanego przez siebie
powietrza.

[Wyrzuć gwizdek](../wyrzucgwizdek/wyrzucgwizdek.md)

[Obejrzyj dokładnie gwizdek](zbadajgwizdek/zbadajgwizdek.md)
