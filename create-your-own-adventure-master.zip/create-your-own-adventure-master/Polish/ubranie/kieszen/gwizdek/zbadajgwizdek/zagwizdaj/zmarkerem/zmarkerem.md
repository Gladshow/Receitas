Marker wydaje się chętni do wykorzystania jak twoja ręka zbliża się do tablicy.

[Narysuj spodnie](spodnie/spodnie.md)

[Narysuj zamek od kurtki](zamek/zamek.md)

[Nabazgraj byle co](bazgroly/bazgroly.md)
