Rozsiadasz si� beztrosko pod drzewem i korzystasz z chwili ciszy.
