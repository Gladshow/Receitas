Drzesz swój rysunek spodni i stwierdzasz, że i tak Ci się nie podobały.

[Zastanawiasz się co dalej zrobić z markerem](../../zmarkerem.md)

