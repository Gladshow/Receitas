Nagle pojawia się postać ze skrzydłami. 
Gwałtownym ruchem chwyta Cię za rękę i momentalnie przenosicie się na ogrąmną łąkę 
na której jest tylko jedno, samotne drzewo.


Skrzydlata postać podchodzi do małej tablicy przymocowanej do drzewa i robi zaznaczenie
obok rysunku gwizdka. Postać uśmiecha się życzliwie i znika w wiatr. Gwizdek w dłoni 
staje się ciepły i zmienia się w duży marker do tablicy.


[Myśląc że zaczynasz rozumieć jak się gra, zbliżasz się do tablicy zdejmujac pokrywke z markera](zmarkerem/zmarkerem.md)

[Przestraszony przez tych dziwnych wydarzeń, sięgasz po gumke do tablicy](zgumka/zgumka.md)

[Rozglądasz się wokół i myślisz jaka piękna łąka](zlaka/zlaka.md)