Du vandrer sydpå og fra bakkerne hører du lyden af [musik](https://www.youtube.com/watch?v=cUGd8X7bjuo).

Men du vælger at ignorere det og prøver at finde et køretøj. Vælger du:

[en rusten cykel](cykeltur/cykeltur.md)

[en traktor](https://youtu.be/kCsSVLZ6wCI?t=31s)?

[at ride med Dick Turpin](https://www.youtube.com/watch?v=n4d3RW488AQ)?

En [forladt bil] (bobbob/bob.md), der holder i vejkanten?

eller

[det ukendte eventyr(kun for de modige)](https://www.youtube.com/watch?v=MFzDaBzBlL0)?
