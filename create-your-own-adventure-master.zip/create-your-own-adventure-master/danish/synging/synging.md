Du siger “Maybe en bette song kan make us in a better humor!”

Hvilken sang vælger du:

[Synge “Knokkel pukkel man“](https://www.youtube.com/watch?v=KPvqm28mL4Q)

[Synge “it's hard to be a nissemann“](https://www.youtube.com/watch?v=JqyjDQGS_Sg)

[Spørge "Then I will go there over and drik some øl with Hansi"](../velkommen.md)
