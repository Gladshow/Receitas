Du befinder på en mark i Vestjylland tilhørende kartoffelavler Oluf Sand og dennes hustru Gertrud.

Sammen med dig er Fritz, Hansi og Günther, der skal finde en nøgle til the Playdåse som spiller Gammel Noks livsmelodi.

Når du kigger sydpå, kan du se Hærvejen som fører mod SønderJylland og Nissernes forjættede once-again-joined-land.

Gammel Nok bliver i sin seng.

Vælger du at:

[Spørge "Well Gynter! How goes it with the snitting?"](snitting/snitting.md)

[Prøver at lette stemningen](synging/synging.md)

[Tage kapsækken på ryggen og vandre sydpå, "Come so med jer! What are you venting for?"](haervejen/haervejen.md)

[Gå en tur i din have] (have/have.md)
