Günther siger "It is not so lige til", og fortsætter med at snitte.
Og det kan han jo ha ret i.

Vælger du at:

[Spørge "Why is it egentlig that you are always, snitting Günther?"](https://www.youtube.com/watch?v=2WS7iJNb4lI)

[Spørge "Then I will go there over and drik some øl with Hansi"](../velkommen.md)
