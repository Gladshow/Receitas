Un matí, t'aixeques en una estranya habitació amb les parets fetes de núvols de sucre.

Què fas?

Tanque els ulls, els torne a obrir. "No pot ser. On estic?"

"Em resulta familiar, però no sé on estic." [Què és això? ](http://www.google.es/imgres?imgurl=http%3A%2F%2F1.bp.blogspot.com%2F-b0CZu7RAyiM%2FULaNOLTJMZI%2FAAAAAAAAAA8%2FwmVTGAKDC-U%2Fs400%2FCaptura3.PNG&imgrefurl=http%3A%2F%2Fsusandsan.blogspot.com%2F2012%2F11%2Fsimbolismo-figuracion-y-abstraccion.html&h=304&w=400&tbnid=jAdgGBhRlYxgwM%3A&zoom=1&docid=j7NOlpg8lyjPMM&ei=xo95VOvhDc7zasWGgaAP&tbm=isch&ved=0CGMQMygfMB8&iact=rc&uact=3&dur=1931&page=3&start=20&ndsp=13)

Què fas?

[Et poses a dormir](dormir/dormir.md)

[Cantes de l'alegria](cantar/cantar.md)

[Penses com sortir d'aquí](sortir/sortir.md)

[Et pessigues el braç](pessigar-se/pessigar-se.md)

[T'aixeques del llit](aixecar/aixecar.md)

[Comences a menjar sucre desesperadament](menjar/menjar.md)

[somrius](somrius/somrius.md)

[Entres en pànic absolut](panic/panic.md)

[Corres cap a la paret més propera](correr/correr.md)