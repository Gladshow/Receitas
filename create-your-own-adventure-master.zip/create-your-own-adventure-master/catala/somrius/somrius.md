Somrius. Content i feliç com quan eres un nen.

El somni de la teva vida de trobar una casa de núvols de sucre, com el d'en Hansel i la Gretel, s'ha complert!

Prens un bocí de núvol i recordes que vols volar. unes ales t'apareixen a l'esquena. Ara tens un dilema, què fas?

[Continues menjant núvols de sucre](../menjar/menjar.md)

[Surts per la finestra i alces el vol](icar/icar.md)
