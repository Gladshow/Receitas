Et poses la m� dreta a la butxaca, treus el m�bil per� no el pots engegar perqu� t'has quedat sense bateria.
Un canari dels que t'est� pessigant que t� el bec m�s gros que tots els altres, se't posa a l'espatlla d'una revolada
i et diu a cau d'orella: "cerveza? beer? amigo"