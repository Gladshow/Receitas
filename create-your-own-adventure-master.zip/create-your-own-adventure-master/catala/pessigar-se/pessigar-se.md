 els ulls i et pessigues el bra� perqu� deus estar somiant i aix� et despertar�s.
Quan obres els ulls els n�vols de sucre s'han convertit en canaris roses que t'estan pessigant el bra� esquerre.
Qu� fas?

[Et menges un canari rosa per veure si t� gust de n�vol](menjar/menjar.md)

[treus el m�bil per fer una foto als canaris i enviar-la als teus amics](foto/foto.md)

[Et desmaies, no soportes els canaris... sobretot els roses...](../dormir/dormir.md)