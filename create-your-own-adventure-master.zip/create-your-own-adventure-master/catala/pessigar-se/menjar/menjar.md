Agafes un dels canaris pel coll i te l'acostes a la boca per clavar-li una mossegada, �s tou com un n�vol..
tanques els ulls, obres la boca i de sobte notes pessics m�s forts al teu bra� esquerre.
Obres els ulls els canaris roses s'han tornat vermells perqu� teu bra� no para de rajar sang!!