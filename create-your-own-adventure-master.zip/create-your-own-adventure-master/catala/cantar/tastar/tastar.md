Tastes una llaminadura en forma de cor, i a fora sembla que para de ploure. Obres la tenda i... tot és de sucre!
El sol regalima lentament sobre l'horitzó gotes de caramel, i et preguntes quin gust deu tindre.

[Et pessigues el braç. Això no pot ser real!](../../pessigar-se/pessigar-se.md)

[Tastes les llàgrimes del sol.](tastes_sol/tastes_sol.md)