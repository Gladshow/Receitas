Tot pareix normal... Els teus amics estan davant un foc
sota la pluja.. Perquè no s'apaga el foc?