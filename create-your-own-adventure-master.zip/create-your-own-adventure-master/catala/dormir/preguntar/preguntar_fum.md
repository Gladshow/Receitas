La mare diu que acaba de sortir del forn i encara crema.

Què vols fer?

[Tasto una mica](../tastar/tastar_arros.md)

[Bufo per que es refredi](../bufar/bufar_arros.md)
