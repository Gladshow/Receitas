Et quedes dormint com un suro. A les 14 hores
et desperta ta mare amb un plat d'arròs al forn.

Veus que surt fum del plat. Què fas?

[Tasto una mica](tastar/tastar_arros.md)

[Pregunto a la mare per què surt fum del plat](preguntar/preguntar_fum.md)

[Bufo per que es refredi](bufar/bufar_arros.md)
