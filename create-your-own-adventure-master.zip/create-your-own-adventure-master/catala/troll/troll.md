De sobte, la roca comença a moure's. T'agafes ben fort a ella per no caure 
mentre veus, sorprès, com es va aixecant del terra un gran troll!

El troll no s'ha adonat de la teva presència, petit que ets, així que et quedes agafat al seu clatell 
sense fer cap soroll, mentre comença a caminar cap al bosc... 
