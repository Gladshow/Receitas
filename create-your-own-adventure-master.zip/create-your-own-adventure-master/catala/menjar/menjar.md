Endrapes i endrapes sense parar, devores voraçment un suau sucre sense saber
el perquè. A poc a poc vas notant que aquest et produeix un rar efecte,
el teu cap comença a sumir-se dolçament en un estat quasi anastèsic de
felicitat i harmonia. És inevitable..

Et deixes anar i caus estès al terra.

Què fas?

No res, has mort. 
I els metges no saben trobar una explicació, però de sucre no n'has menjat pas.