Dreams to Memories – Wisdom in Ladakh. 
A ride to ladakh requires a lot of preparation and begins 
with convincing folks back home and also at the office.
As a popular quote says “Four Wheels move the body and two wheels move the soul”
just riding 2500 Kms in 15 days was not the only objective
of the dream I had for some time now. 
It was also to ensure that there is enough learning from the ride to be taken 
back home and be a better human being apart from being a better rider.
The ride on a RE to ladakh was in preparation for almost 3 years
and as Kabir said “Slowly slowly O mind... 
Everything in own pace happens, Gardner may water a hundred buckets...
Fruit arrives only in its season”, 
and happen to participate this July on the ride with ~70 other riders.
The ride included a lot of scenic beauty,
the challenge of riding on various kinds of surface gravels,
slush, watercrossing, sand and tarmac included,
mental and physical challenge. 
One of the first ritual of the day was briefing which included the route,
regroup point, road situation, mistakes committed by other riders and challenges.
One thing every rider was keen to listen during briefing was Riding Tips.
These were not just the tips for the ride of the day but
for the entire journey and was expected to be taken back home
and apply when you ride anytime and anywhere. 
Every person’s life is a journey and we come across various challenges
and paths which we have to cross and move ahead. 
The tips do have hidden meaning which I happen to think during
the ride as to how this can benefit our daily life

