You dial Sauls number...

"Hi, its Saul Goodman!"

"Wise cracking "lawyer" with questionable ethics?"

"That's the one!"

"Great. Saul, I'm really tired but I have so much to do. Can you help me?" you ask.

"Sure," he says, "Just use the [Cinco Face Time Party Snoozer](https://www.youtube.com/watch?v=Tvu2ZI329V4)."

Clearly you are not good and you think you are being pranked so you
[go back to thinking about what you should do](../marshmallow.md)
