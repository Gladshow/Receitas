"doot doot!" - mr. skeltal

good bones and calcium are in your future!

plz updoot

mr. skeltal is nice!

hahahaha

'sup?

no your face!

but words!

[Go back to sleep.](../sleep/marshmallow.md)

[Check DC Comics.](../DC-Comics/epic_DC_Character.md)

[consume combat ration](../combatration/combat_ration.md)
mmmm combat rations...
