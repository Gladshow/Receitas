So to continue with the story, the situation was tense, but suddenly everything got solved on it's own.
The Epic Sexy Sax Guy appeared at the scene and with his powerful skills with the sax, he calmed even the most affected 
by the catastrophe... [Click here to receive the epic sax guy music] (https://www.youtube.com/watch?v=BYEFv6sgKrM)