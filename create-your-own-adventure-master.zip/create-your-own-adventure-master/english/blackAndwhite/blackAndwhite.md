Black and White, Chapter 1:


Christy wakes up to a creepy noise of footsteps circling around her bed and
She shuts her eyes hard and holds her quilt tight. The volume of footsteps descends and
Christy opens her eyes and slides the quilt off her face. She looks around and finds no one
around. She's drenched in sweat and breathing heavy.

Christy steps off the bed and scans her surrounding in her dorm room. She's alone but she feels
that someone is watching her, someone is recording her and she strong believes that someone wants to kill her.
Christy walks back to her bed and slide into her quilt.

Along the direction of the wind, through the window next to the bed, A tall and toned young man, 
wearing a leather hood and jeans, smirks seeing Christy tremble in fear.

Christy sprints to the window to check if someone is hiding there and sees no one. Stranger drifts into the eternal dark
and leaves a puzzle behind for her.

Christy's phone vibrates and drops off the table and Christy screams in dismay waking up the entire dorm.