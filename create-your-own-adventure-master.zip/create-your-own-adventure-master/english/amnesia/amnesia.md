After eating marshmellows i can't get no sleep. Freaky noises make my
skin creep. I can't get no sleep.
I try some tea, it gets me nowhere.
It's probably because the marshmellows where filled with horse hooves
It's definitely throwing off my groove:(
Then I open my mac and log on to udacity,
All I see are lessons that can help me :)
Distraction is a foe.
But where am I? I do not know.

[Sit back down, to get no sleep?](../sleep/marshmallow.md)

[I bet I could dance my memory back into place!](../dance-randomly/dance-randomly.md)

[Wait, something's coming back to me!](../I'm-batman/batman.md)

Amnesia can be freaking awesome sometimes :)

Or it can be highly disturbing.

Like when you wake up from a [dream](http://www.asdreams.org/) and slowly the vivid
memory of it fades away. Like switching from one life to another.

Or, it can be highly... oh, I forgot what I was going to say.

Who am I?  Where am I?  What am I doing?

My name is...I am Daniel.

All your quesions can be answered by going [here](https://www.amnesiagame.com/#main).