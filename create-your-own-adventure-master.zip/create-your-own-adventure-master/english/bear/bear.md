Stella atroir.
Taiwan bear.
Ice cold. If warm, the results could be unbearable.
Bear in mind, the grizzly taste.
You are now drunk. You stumble over to the nearest cutie and ask, "Hey baby, what's ursine?"

When she slaps you in the face...

[You vomit on top of her](../vomit/vomit.md)

..., holding your hand to your red cheek [you say] (../slap-response/slap-response.md)

all is not what it seems in this story.
you're talking about bears, but i'm talking about 
[bears](https://twitter.com/ChicagoBears?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)
