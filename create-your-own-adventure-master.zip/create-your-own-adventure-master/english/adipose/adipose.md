You remember you took your diet pills before going to sleep.
The marshmallows are in fact your Adipose!
You die from fat drain.

You are absorbed into the marshmallow wall and now you wait with the others for new recruits.

You emerge from the wall a marshmallow human. You now resemble the Michelin man. 

As you ponder your place in the universe, you feel a slight fire under your
feet and begin to worry... "Am I a human dreaming I'm a marshmallow being
roasted alive, or am I a marshmallow being roasted alive who awoke from a dream that I
was a human?"

I must resolve this marshmallow dream.

[Wake Up](awake/awake.md)

You realize you can't wake up. Or you are already awake. But you must continue because

winter is coming.  

Hot cocoa will be sold at nearly every street corner, and your sweet
scent will likely have the drinkers plucking pieces of your being for their drinks.  

Sure, it's not right as it's not consensual, but you have a hazy memory
of a long ago cold night where you were running after having just
passed a cocoa house.  The people all started following you with their
warm, steamy cups held fully out as they chanted "mellows, mellows".
It eirily reminded you of a story you read as a young fluff, but the chant was, "brains, brains".

You couldn't quite decide whether you were awake or asleep, 
but as time was running out, you remembered something your mother always told you...
[Mom's Advice](../advice_from_mother/advice_from_mother.md)
