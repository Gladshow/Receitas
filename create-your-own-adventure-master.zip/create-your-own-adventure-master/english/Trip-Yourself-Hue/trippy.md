Choose your poison, get your brains all mooshed up     
      
--> [Pony](https://www.youtube.com/watch?v=X0gyqsPdWFE)   
     
--> [Horse](https://www.youtube.com/watch?v=QCGcCC065CY)   
    
--> [Cake](https://vimeo.com/128877443)     
     
--> [MaryJane](https://www.youtube.com/watch?v=JIpv81BH8Wo)      
