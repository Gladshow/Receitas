The batphone rings. Its commissioner Gordon telling you Catwoman just robbed Gotham National Bank!

Do you pursue Catwoman?

[Yes](pursue/pursue.md)

or

[No](vacation/vacation.md)