Did you know that your parents died and you are left with Wayne Manor? Golly Gosh Batman!

Be careful of the Joker!

[Realize that you are Batman and have the Utility Belt on you. Yeah!!!](https://youtu.be/YpIQQeL2ZYk?t=22s)

Alfred Pennyworth: Why do we fall sir? So we might learn to pick ourselves up.
Bruce Wayne: You still haven't given up on [me](https://www.youtube.com/watch?v=u843KNE-exo)? 

Batman: [It's time...](../batmetal/batmetal.md)

The batphone is ringing, [answer](catwoman/catwoman.md)?