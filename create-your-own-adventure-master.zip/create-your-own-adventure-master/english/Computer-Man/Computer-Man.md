You're walking down the street, and the glint of a flashy new computer
catches your eye through the window.  You walk into the store, and
meet.......the [computer man](https://www.youtube.com/watch?v=Hm4E8TcjF70).

[Restart] (../marshmallow.md)
