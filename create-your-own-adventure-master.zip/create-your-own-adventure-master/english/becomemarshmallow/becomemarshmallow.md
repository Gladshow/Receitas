You decide to become a marshmallow.

After 42 days in hiding, they realize you are not really a marshmallow after you are caught eating Steve.

They return the favor and make a s'more out of you.

RIP marshmallow you.

You will be remembered!

But for what? The sweetness or for being caught?