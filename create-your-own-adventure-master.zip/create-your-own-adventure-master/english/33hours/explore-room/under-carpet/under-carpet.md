Under the carpet there are only floorboards. It looks like one of them might be loose.

[Remove floorboard](remove-floorboard/remove-floorboard.md)

[Replace carpet](../room.md)