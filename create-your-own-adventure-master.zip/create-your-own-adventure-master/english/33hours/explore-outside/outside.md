You open the door and step outside in the bright sunshine. It takes a few seconds for your eyes to adjust and only then
do you see your surroundings. You are standing near a long two-lane highway that stretches off into the distance to your
left and your right. You stand there several minutes, but see no cars at all.

The motel parking lot is completely empty. It looks to be abandoned. There are no other buildings around for as far as
you can see.

[Go back inside and explore the motel room.](../explore-room/room.md)

[Start walking east, on the highway](explore-outside-east/explore-east.md)