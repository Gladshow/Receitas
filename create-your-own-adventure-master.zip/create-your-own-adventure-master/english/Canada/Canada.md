Well, looks like the end of a long and beautiful empire.
(Insert name of politician you don't like) has won. What do you do?

Alright. You're ready. 
Let's head off to the [true north strong and free](https://www.youtube.com/watch?v=9yFs7K27kZI).

Make sure to brush up on your English: it's [zed, not zee](https://www.youtube.com/watch?v=BRI-A3vakVg).

Perhaps [applying for status as a political refugee](http://www.cic.gc.ca/english/refugees/outside/index.asp) 
would be one way to go?

Or maybe you work in a [NAFTA profession](http://www.cic.gc.ca/english/work/special-business.asp)?

Thinking about marrying that cute Canadian student 
who sits next to you in class to get away from all this chaos? 
[Sorry buddy, I've got bad news](http://www.cic.gc.ca/english/helpcentre/answer.asp?qnum=357&top=5).

No dice? Yikes. 
Guess you'll have to stick around and 
[enjoy all this freedom](http://weknowmemes.com/wp-content/uploads/2011/12/damn-right-im-free-this-is-america.png), eh?

