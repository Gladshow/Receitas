You look around the walls and study them in detail. Marshmallows of various
sizes and delicious pastel colours cover the surface. You start to methodically
inspect them in sequence, running your fingers over the soft cushiony powdered
surface.

While recalling campfire's of past, you suddenly realize you have sensed an area
that is completely flat! It's glass - covered with an image full of marshmallows.
The detail and quality of the image is amazing. It would  have been so easy to
miss. You step back, preparing yourself for what this could mean.

Could this be the link to the outside of the room you seek?

Tentatively, you slide you fingers across the glass - looking for the edges.

The image changes and a border is now clear.

A 3D green droid figure displays with V6.0 stamped on its metallic chest. In its
arms is a single marshmallow.

The green droid figure bows down to a silvery apple.

In haste you take up the marshmallow as your charge.

As you depart the little droid calls you to "Seek out from whence you came, and find the nougat..."