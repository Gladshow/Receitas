You walk down the tunnel and feel faint. You blackout and right before you hit the floor someone catches you.
While you were blacked out you recall something you were [hypnotized to forget.](../hypnotized-to-forget/hypnotized.md)
