Fullmetal Alchemist (Japanese: 鋼の錬金術師 Hepburn:
 Hagane no Renkinjutsushi?, lit. "Alchemist of Steel") is a Japanese 
manga series written and illustrated by Hiromu Arakawa.

 It was serialized in Square Enix's Monthly Shōnen Gangan
 magazine between August 2001 and June 2010;
 the publisher later collected the individual
 chapters into twenty-seven tankōbon volumes.
 The world of Fullmetal Alchemist is styled after
 the European Industrial Revolution. 
Set in a fictional universe in which alchemy
 is one of the most advanced scientific techniques,
 the story follows the Elric brothers Edward and Alphonse,
 who are searching for a philosopher's stone to restore
 their bodies after a failed attempt to bring their 
mother back to life using alchemy.

Click [here](../alchemy/alchemy.md) to learn more about alchemy.

[Don't know what to do next?](../working/working.md)

But this is just the beginning. To become full weeaboo trash, you must fall down
into the depths of [idol hell](../LoveLive/lovelive.md)...

With great power, comes great responsibility.
