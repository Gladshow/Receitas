You are on the right way, son!

Just try the new android version marshmallow version 6.0 .

Check the updates for your smartphone now!


There are two options here:

1. You have an update, and won't read this further;
2. You are unlucky one, and you better [choose another path](../marshmallow.md);