[A nose length away from the wall, a twinkle in your mind makes you pause.](padded-room/first-blackout.md)

"Mmmmm... these marshmallows are soooo good. They would be delicious with a cup of coffee." 

You close your eyes.

You smell your favorite Starbucks Latte and you take a sip.
Then you take a bite of marshmallow.

Suddenly there is a horrible pain in your mouth! Who would have
thought marshmallows, so white, so innocent, could cause such
excruciating pain! But come to think of it, you've never gone
to the dentist about that root canal he recommended almost a
year ago, and perhaps you should have gone back instead of
trying to save a few bucks...

hundreds of bucks actually!

Wait a minute....how did you end up in this car?  You must be hallucinating 

[You use the gps to get back home](https://www.youtube.com/watch?v=RvlhrgSZrfA)

[You open the door and there is a man sitting on your couch](../movie-ripoffs/zoolander/zoolander.md)

[Ask the driver "Where are we going?!"](ricky/ricky.md)

Magically, the car pulls up in front of your dentist's office.
[You get out and go into the office.](dentist/dentist-office.md)

[Procrastinate with social media](../lamping/lamping.md)