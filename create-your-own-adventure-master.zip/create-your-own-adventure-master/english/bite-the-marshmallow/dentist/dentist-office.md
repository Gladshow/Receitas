As you walk into the dental office, the pain in your mouth subsides.
Just as you start feeling happy that your mouth doesn't hurt anymore,
you look around and realize you're back in that weird room with the marshmallow walls.
The garishly dressed, vacant-eyed young man is still lounging on the sofa.

[Interrogate the man for clues](../../movie-ripoffs/zoolander/zoolander.md)

You hesitate talking to this man, thinking, "Eh, he's probably crazy and won't say anything helpful,"
then, all of a sudden, this mirror-like thing came crashing down from the ceiling right in front of your face.
You swear it is whispering: ["Come on in!!!"](../../mirror/enter-mirror.md)