After a brief testing of your restraints you realize that when you shift your weight to your right side
you can wiggle your wrist in the restraints and might just make it free.
You notice the distant hum growing louder. 