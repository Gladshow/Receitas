The twinkle bursts into flashes of memory that assemble your senses into a perception
of where you are. Tendrils of deja-vu tug at your mind reel your conscienceness to the disturbing truth. 
This looks like the padded cell from a movie or television show.

Another tug, this time on your arm, turns into a sharp pain of an needle snaking back to
an IV bag. 

Footsteps grow louder, then faster. The room starts to fade. Voices. Darkness. 

...

You awake with a sense of groggy dread and force your eyelids to open up (very much 
against their wishes). At first the bright light blinds you and hurts your poor 
retinas, but after a few seconds you adjust and take a look around. You appear to be 
strapped to a gurney in a narrow (but brightly lit) corridor. The walls and ceiling 
are white and spotlessly clean. The floor... well, you can't see the floor. In the 
distance you can hear a faint humming sound, but you appear to be all alone at the 
moment. Well, now what? Perhaps you could [call out](call-out/calling.md)?

You could also quietly [struggle](escape/escape.md) against your restraints.
