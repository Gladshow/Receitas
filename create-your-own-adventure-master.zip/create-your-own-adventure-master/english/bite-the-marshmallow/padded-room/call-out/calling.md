You attempt to call out for assistance, but your throat is dry and your voice is 
raspy and quiet. Well, that's that, I guess, you think to yourself. I'll just wait 
here... indefinitely. Then you notice a small white tube sticking up from your armpit 
that may just be within reach of your poor, chapped lips, and you notice the pressure 
between your arm and torso that can only mean a foreign object has been wedged in 
there. Looks like someone has thoughtfully provided you with something to quench your 
thirst!