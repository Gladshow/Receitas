You see a suave young man driving the car in no discernable direction. 
He peers into the rear view mirror, head tilt down, 
his eyes rising above his cool-cat sunglasses.

"You don't need to know where we are going. 
All you need to know is that I'm never gonna give you up!"

[Finish the drivers mysterious answer](https://youtu.be/dQw4w9WgXcQ?t=42s) 