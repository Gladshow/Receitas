In the Pursuit of Happines
Let's try to stay happy like them. [here](https://www.youtube.com/watch?v=8mP5xOg7ijs)