1) "Too many of us are not living our dreams beacuse we are living our fears."

2) "When you're scared, you stay as you are!" -Stephen Richards

3) "There is no illusion greater than fear." -Lao Tzu

4) "Man needs his difficulties because they are necessary to enjoy success." -APJ Kalam

Click [hear](https://www.goodreads.com/quotes/tag/overcoming-fear) to find more quotes. 