In this world, fear has no place. Only strength respects strength.

Fear is an unpleasant emotion caused by the threat of danger, pain, or harm.

So we have to overcome our fear.

There are some quotes :-

[QUOTES](quotes/quotes.md)