My name is Oliver Queen, formerly known as the hood, now known as the arrow. No one knows my identity due to my superior
disguise...

"Yeah, dude, how can nobody NOT see your face? I mean, it's just a hood. Your voice morpher doesn't help much either. 
SOOOOOO obvious."

The Arrow twitches. He draws an arrow and nocks it to his bow, his anger rising.