Surprisingly, this is not really marshmallow. It only looks like it but in reality it is made out of... 
Let me guess, your favorite flavor of marshmallow is avocado; mixed with some [coffee](../coffee/coffee.md)

[motor oil](../motor_oil/motor_oil.md)
