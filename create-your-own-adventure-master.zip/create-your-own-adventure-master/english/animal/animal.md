My worst fears have come true.  My cat is crying out for food.
The screams are the worst sound I’ve ever heard in my life.

Even if it really start to drop tears or weep blood, it's the same to me ... no food.
The hilarious thing is that i start thinking about making it my own meal.
I remember my last meal, oh it was a dead dog 3 days ago.
We are stepping to the verge of eating each other, human flesh oh what does it taste.
I've heard that it tastes like pork...


OMG WHAT SHOULD I DO??
I NEED HELP...

I wonder what the cat would do if I gave it a hot dog. I know 
what I would do. 

I'd eat it. Yup, I know it sounds disgusting but a dog is a dog and a cat is a cat.
You know what I mean?

Don't eat animals #GoVegan

Don't be cruel.

one more animal.

Maybe two more bites...

oh! i have a great idea. why don't we get ourselves a mouse? me and the cat would be both satisfied...


No. No.  A hedgehog would be the far superior choice, as hedgehogs make great pets
and all the girls would stop and ask you what it is.  You could chat them up.  Maybe get their
phone numbers?  

This could happen.  And you could exchange phone numbers and maybe spend the rest of your lives
together, just because you chose to get a hedgehog, rather than a mouse!!

My mother was a butterfly. Is that true? No it is not.

I love animals, they are delicious.

