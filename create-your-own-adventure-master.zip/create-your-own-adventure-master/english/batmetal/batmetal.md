WARNING: Entering heavy metal zone!

[I AM BE DANGEROUS NOW](https://www.youtube.com/watch?v=qatmJtIJAPw).

After shoving around pimply longhaired teenagers in the pit for a bit and 
knocking out that one obnoxious, sweaty (and of course, topless)  baldhead, 
you hear the singer shout: I... NEED... MORE.... STAGEDIVES!

You growl, which is what you always do when pondering important life decisions.
After all, you are the batman. The kids surrounding you take a cautious step back.

WDYD?

...pull out your grappling hook and prepare to [enter the stage](stagedive/stagedive.md)

...start doing your signature [bat-mower](https://www.youtube.com/watch?v=6RkyxNa2W9o)
(c) move, much to the dismay of punters left and right, who unlike you, are not wearing 
any bullet-proof armour. So what, you think. I AM THE BATMAN!

