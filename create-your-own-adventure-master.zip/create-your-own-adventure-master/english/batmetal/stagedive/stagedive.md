... you aim your grappling hook at the ceiling stage lights and fire. You ascend 
towards the stage, knocking over that guy in cargo shorts with the nose piercing
in the process. So what! You are the batman! The singer and the rest of the band 
look a bit scared after you gracefully descend on stage next to them. No need to 
ask for the mic, you just grab it and in your deepest, meanest growl, you scream.. 
