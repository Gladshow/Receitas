There once was a prince who was angry.

It was peace time and he had a lot of duties to do. But his rumbling rage was too powerful to handle.

He decided to take the biggest sword in the kingdom.

It was this [sword](https://i.ytimg.com/vi/ICatpGotaNs/maxresdefault.jpg).

Satisfied with the sword, He asked for the craftsman to come in his palace to thank him.

Little did he know, that sword will change everything he knows....

But more on that later. For now, the prince must tend to his royal duties.