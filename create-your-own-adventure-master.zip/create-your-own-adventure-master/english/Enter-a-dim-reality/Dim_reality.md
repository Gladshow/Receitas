Something strange happended after speaking those magic words..
You keep your eyes closed, afraid to open them - anticipating a
shift to an even stranger place.  Slowly you open them.  You blink 
several times, but there is only darkness. 
You muster the courage to take a step into the blackness, it seems that 
you are on solid ground - for the moment.Something echoes in the distance, straining 
your ears you frantically try to find the source of the sound on 
the dark horizon.  A dim light comes into focus, its hard to tell 
how far off.  Get to the light. Your timid steps quickly turn 
into a jog, the cool moist air is invigorating.  The light 
doesn't seem to be getting any closer, you begin to run faster.
Eventually you are out of breath, and you stop to rest.  The 
light is still on the horizon, perhaps a bit closer, perhaps 
not.  As you gear up for continued pursuit, you notice another 
light, in the opposite direction, the direction you came from.  

Do you [continue forward?](continue-forward/Forward.md)

Or do you[go back?](go-back/goBack.md)
