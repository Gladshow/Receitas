You decide its not worth it to jump.  Too risky.  Sit on the edge,
feet dangling, wondering where the hell you are.  What are 
you looking for?  An exit?  Doesn't seem like there is one. 
Who knows.  Everything begins to shake.  The ground crumbles
beneath you, and without flinching you accept your fate, 
you feel yourself falling, pieces of rock surround you, 
the bigger ones whizzing past your head, the smaller ones 
floating all around you.  You've been falling for awhile
now, you anticipated a meeting with crunching fate much 
sooner.  You become comfortable with the sensation of 
falling, and you begin to maneuver your body so that you
can look around.  You begin to realize that you aren't 
falling, you are in some kind of orbit.  A faint but 
perceptible orb of light is in the center, and you are
among a river of rock trapped in an enclosing flow.  
You start pushing off the rocks around you, gaining
momentum towards the middle.  A well timed 
push off of a car sized rock sends you on a trajectory 
headed straght for the center.  As 
your fingers wrap themselves around the orb of 
light you feel your body melt away. You are one 
with it.  You are omnipotent.  NICE!
