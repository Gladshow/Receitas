You decide to go back, you haven't been running for that long after all,
and this light looks a bit brighter than the other..  You start moving
agian, and slowly, this new illumination brightens the horizon.  
Suddenly, you feel compelled to stop.  You scan the horizon and 
realize that there isn't a distinct light source like before, 
instead there is a uniformly dull glow, a stripe of phosphouresence 
in the void.  As you you try to focus on the brightest point,
you begin to realize that it is getting brighter.  The light 
is quickly swallowing the darkness, and the ground around you
becomes visible.  Good thing you stopped.  You are standing 
on the edge of a fissure.  There is no perceptible end to 
the crack in either direction, but the other side is pretty
close.. close enough to jump?

Do you [jump](Back_Jump/goBackJump.md)

Or do you [stay put](Back_Stay/goBackStay.md)
