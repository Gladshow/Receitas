You jump in and begin to swim.  The water is ice cold, pushing you
to swim faster as you attempt to keep your breath.  You reach the
center of the pool, you are still - treading water, as you look 
into the brilliant mass of effervesence suspended inches from 
your face.  Slowly, you move your head closer and closer - as 
your skin breaks the barrier of the sphere you can no longer 
feel your body.  You suddenly know all.  You have transcended. NICE!
