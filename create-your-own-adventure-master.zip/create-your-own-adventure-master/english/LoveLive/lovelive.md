Love Live! School Idol Project (ラブライブ! School idol project) is a Japanese multimedia project
 co-developed by ASCII Media Works' Dengeki G's Magazine, music label Lantis, and animation studio
 Sunrise. The project revolves around a group of fictional school girls who become idols in order
 to save their school from shutting down. It launched in the August 2010 issue of Dengeki G's Magazine,
 and went on to produce music CDs, anime music videos, two manga adaptations, and video games.

A 13-episode anime television series produced by Sunrise and directed by Takahiko Kyōgoku aired
 in Japan between January and March 2013, with a second season airing between April and June 2014.
 An animated film titled Love Live! The School Idol Movie was distributed by Shochiku and released
 in June 2015. Both anime series and the film are licensed in North America, the United Kingdom,
 Australia and New Zealand by NIS America, MVM Entertainment and Madman Entertainment, respectively.
 A separate project titled Love Live! Sunshine!! focuses on a new group of school idols, and an anime
 television series based on the project premiered in July 2016.

[Source: [Wikipedia](https://en.wikipedia.org/wiki/Love_Live!)]

Now that you've gone full weeaboo, you've prepared yourself for the 700+ episodes
 (as of July 2016) of the hit anime series [One Piece](../onepiece/op.md).

[Link](http://myanimelist.net/anime/15051/Love_Live_School_Idol_Project) to info
 about the first season.

[Link](http://myanimelist.net/anime/19111/Love_Live_School_Idol_Project_2nd_Season) to info
 about the second season.

[Link](http://myanimelist.net/anime/24997/Love_Live_The_School_Idol_Movie) to info
 about the movie.

[Link](http://myanimelist.net/anime/32526/Love_Live_Sunshine) to info
 about Sunshine anime series.
