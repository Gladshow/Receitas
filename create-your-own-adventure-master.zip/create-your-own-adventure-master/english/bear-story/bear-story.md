"[Yuna](https://xantandminions.wordpress.com/kuma-kuma-kuma-bear/). 
Nice to meet you," 
she says, as she dances around in her bear dress 
and summons two giant bears to haul you away to 
another fantasy world as her bear slave. 

You end up in the body of a 10-year-old and are 
forced to participate in the bear takeover of the world!

This is the price you pay when you lock eyes with a
dancing bear.

