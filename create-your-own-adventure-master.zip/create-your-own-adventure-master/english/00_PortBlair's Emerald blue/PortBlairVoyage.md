# I landed on Port Blair on **26th Jan** 2008

#### Why this day is special ??
######  [Republic day of India](https://en.wikipedia.org/wiki/Republic_Day_(India))

##### I was on the ship named MV Nicobar. 
See [here](https://en.wikipedia.org/wiki/Republic_Day_(India)) 
for more details about ship.

>I was greeted with a pictersque view of the Rajiv Gandhi Marine National Park.
>The Lush Green scenary surrounding me was so overwhelming. 






