Always do your best. What you plant now, you will harvest later

