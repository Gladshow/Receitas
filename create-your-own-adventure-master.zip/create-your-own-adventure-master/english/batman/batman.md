wanna know a secret bruce wayne is the BAT 

Batman is awesome!

click [here](https://en.wikipedia.org/wiki/Batman) and see it for yourself.

Click [here](http://www.google.com) to visit Google.

Click [here](http://www.imdb.com/title/tt0096895/) to visit IMDB.

But I know what you're wondering. If Bruch Wayne is the Bat, then who is Bruce Wayne? Well it's obvious...

...IT'S JOHN CENA!!!

And that's why both Batman and John Cena's theme songs always seem familiar even if you've never heard them before!

but you wonder does it end [here?](../movie-ripoffs/selfaware/selfaware.md)

But then you realized that Bruce Wayne is really John Travolta from Face Off! Holy toledo! You jump up and down at
this realization, then you go:

[tell papa-louie and he says...](../papa-louie/papa-louie.md)

Bruce Wayne: It's not who I am underneath, but what I do that defines me.

Commissioner Gordon: He's the hero Gotham deserves but not the one that it needs right now.

Uncle Ben: With great power comes great responsibility.
(Hey Uncle Ben was a character in Spiderman!!, doesn't belong here)

The real hero is alfred the butler..
Who is really 
[Luke Skywalker's](http://fellowshipoftheminds.com/2015/11/23/star-wars-goes-to-illuminati-dark-side/) son!

He also gets really weird with his [neighbors](http://imgur.com/gallery/Gi9cwgR).

I am batman's cousin.

Now that Bruce Wayne is grown old, he has proclaimed that I should take over his legacy!

Over my dead body!! Says Robin.

John Cena comes busting through the wall and screams:

"I'm batman!"

And in typical smark fashion, the crowd boos and chants "John Cena Sucks"

Another shouts "Who is John Cena"

"Goodluck talking to John Cena"

"This is the last time i am talking to John Cena"
