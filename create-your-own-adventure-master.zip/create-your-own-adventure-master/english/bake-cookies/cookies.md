Baking is therapeutic for you.  You remember
learning to bake from your grandmother, or if not your
grandmother, then off the TV, and how
relaxing and happy that always makes you.  You
want to spread the joy (and chocolate chip cookies, or peanut butter, or 
ginger).
Probably you love cookies too, or at least you like the idea of them.
Because cookies are awesome!!!
If you don't have time and want to eat delicious cookies, then get some from Sprouts!
Do you:

[Invite friends to share?](../invite-friends/friends.md)

[Sing a song?](../sing-song/sing.md)

[Make coffee first?](../coffee/coffee.md)

[Breathe?](../yoga/breathe/breathe.md)

[Want to get high?](../weed/weed.md)

[Call a doctor?](../call-a-doctor/doctor.md)

[Don't know what a cookie is?](https://en.wikipedia.org/wiki/Chocolate_chip_cookie)
