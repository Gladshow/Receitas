	All of a sudden, a bird swoops down, big as a bus, and snatches the 
marshmallow right off of you.

    You are shocked...

	Amazed, you sit in silence at the mythical animal you just witnessed ...
as well as trying to catch your breath...and, in the distance, glimpse
what appears to be a horse with a horn sprouting from its forehead...

You really have only one option
[Go ask Alice](../ask-to-alice/ask-to-alice.md)
I think she'll know ...

The pressing question is whether Alice can help in time to avoid nightfall
and the inevitable zombies that sprout from dark corners. 
[Gather wood](../you-are-in-minecraft/gather_wood/focus_on_gathering_wood/focus_on_gathering_wood.md)
