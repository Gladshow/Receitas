You remember a friend telling you that the Bird is the word.

This gives you hope

A New Hope, A Hope you havent felt in a while

So you

[Sing a song](../sing-song/sing.md)
