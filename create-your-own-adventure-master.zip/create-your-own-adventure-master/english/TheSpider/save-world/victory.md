YOU'VE SAVED THE WORLD. 

WITH GREAT POWER COMES GREAT RESPONSIBILITY

Excellent job. Pat yourself on the back. You're done. 