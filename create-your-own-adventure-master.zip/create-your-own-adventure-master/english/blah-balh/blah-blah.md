Say something, just talk, so everybody can listen to the voice you have to offer to the world. But please do not yell.

Be as smart as you can be in your voice so you don't sound stupid.

And sing if possible. Singing cheers people up.

If no sing [go back](../marshmallow.md)

[Sing](../singing/singing.md)

[Say something, just talk](https://www.youtube.com/watch?v=XfWnITmT1Ws)
