The very first question you should ask yourself is about the position you want to play.

If you want to score goals, you would probably be a Striker.