Why not ask a question on Quora when you are feeling confused?

Click [here](http://www.quora.com) to visit Quora.
