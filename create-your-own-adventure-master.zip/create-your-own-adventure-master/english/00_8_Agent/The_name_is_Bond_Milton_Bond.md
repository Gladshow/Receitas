You have entered into the world of a secret agent.
If you used to be a Drill Master, you should aspire to become 
a [White Tiger](https://play.google.com/store/apps/details?id=com.linecorp.LGRGS) instead.

If White Tiger is too dull, you may choose a 
[Tiger Bear](http://i0.wp.com/listverse.com/wp-content/uploads/2011/05/liger.jpg?resize=548%2C426)

You have entered into the world of one of Her Majesty's secret agent.
Codename Agent 008; his name is Bond, Milton Bond.
He's the pencil pushing assistant of his more well-known cousin, [James](http://www.007.com/characters/the-bonds/).
While James is out stopping evil-doers, rescusing damsels in distress, and having the occasional martini.
Milton is responsible for making sure all of James' paperwork is in order.
Need the requisite form for a new Aston-Martin for that high speed car chase?
Ask Milton!
Special ordering a bespoke tuxedo for a fancy dinner and with a side of fisticuffs?
Milton's your man.
Need someone to send in your end of mission expense report, complete with TPS cover letter. 
Milton's already one step ahead of you.