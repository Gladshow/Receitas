You grab for a handful of hot, gooey goodness and cram it into your gaping maw.
This was maybe a mistake.

Unfortunately, it's hard to taste the sweetness of the marshmallow
with a mouthful of seared flesh.

Your screams are incredible. In your agony you lose consciousness, collapsing to the floor.