The door thuds open and the light coming from within the room in front of you blinds you momentarily.

When your vision clears, standing before you is Bob Barker in all his glory.

You stare at him in awe.

The Barker beauties are nowhere to be found; you collapse for a moment in dispair.

He doesn't look a day past 50.  Like all of the greats he doesn't age in your mind.

He is flanked by two of the hottest...marshmallows that you have ever seen.

They are literally on fire, like they have been toasting on an open flame and they look delicious.

Bob with a gleam in his eye, looks at you and says, "Come on down you're the next contestant on the .md is right."

You step into the room and walk up to Bob.  Behind him are two large doors.

The flaming hot marshmallows are gesturing suggestively at the doors while swaying their flaming hips.

They grin with barely hidden glee.

"Which door is the door for you, the blue door, or the red door?", he asks.

"Before you decide, Remember help control the pet population. Have your pet spayed or neutered.", he announced.

You hesitate just a moment before replying...

[The blue door](1970s/1970s.md)

[The red door](2050s/2050s.md)

[Grab some coffee?](../coffee/coffee.md)

[Can I phone a friend?](phone-a-friend/phone-a-friend.md)

[Attack and eat one of the marshmallows](eat-marshmallow/hot.md)
