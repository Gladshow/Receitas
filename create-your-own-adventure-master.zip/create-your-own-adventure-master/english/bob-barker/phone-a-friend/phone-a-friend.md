"Sorry bud, wrong show.," replies Bob sarcastically.

Your ears are full of gooey marshmallow, so you ignore Bob's turgid response and reach for your
flip-phone and begin to phone the first person that comes to mind....