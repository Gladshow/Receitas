Suddenly, a warm wave flows over your body and all of the objects around you are in sharp focus. You can
feel the your inner brewer start to explode into your reality. You intuitively know that brewing is an art
passed down from generation to generation, and that you are an Ale-i Knight and the beer force is strong with you.

You also feel a slight shift in gravity - could you be slowly slipping toward the Dark Side? You try to resist,
but the urge to brew a porter is overwhelming.
