You decide that brewing beer might be a good idea.

You go to a beer brewing store and realise that you have no idea what you're doing.

You dream of beer, and start to research beer on the internet, but it's still confusing.

What should you do?

Decide that its better to just give up and drink some [Beer](https://www.youtube.com/watch?v=yzcEG_JoVuo)."

Learn how to brew from some online [videos](https://www.youtube.com/watch?v=qCW-SVPCw4Y)

You hear a soft voice with an English accent that says, "[Use the force.](use-the-force/force.md)"

Go call [Saul Goodman](../better-call-saul/saul.md)

Give up and go back to the [beginning](../marshmallow.md)
