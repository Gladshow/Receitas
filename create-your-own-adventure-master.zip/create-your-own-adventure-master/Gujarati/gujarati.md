When object to be gained is sufficiently valued, 
and efforts towards its attainment are persistently 
followed without intermission, then the steadiness of mind is secured.

A problem is achance for you to do your best.
Tha best way to predict the future is to create.

Gujarati language is great. Lord Krishna spoke or led to it. Mahatma Gandhi spoke and wrote in it.

ગુજરાતી ભાષાનાં પરાક્રમી સફરોમાં આપનું સ્વાગત છે. અગણીત સફરો માંથી તમે કયું પસંદ કરશો?
તમારી ખરી કસોટી શરુ થાય છે. તમને ખુબ શુભકામના.

[ઉત્તરાયણમાં ખેંચ કે ઢીલ?](ઉત્તરાયણ/ઉત્તરાયણમાં ખેંચ કે ઢીલ.md)

CS [go here](DhoklaStellarFafda~/CS.md)

ટીપે ટીપે સરોવર બંધાય , કાંકરે કાંકરે પાડ બંધાય
This is my favourite Gujarati proverb copied from [here](http://gujarati-proverbs.tumblr.com/)

જાગ્યા ત્યાંથી સવાર
Mine favourite(@ http://gujarati-proverbs.tumblr.com/)