Tara kain tayo ng pizza at fries, masarap ito eh !
Inom din tayo ng beer !