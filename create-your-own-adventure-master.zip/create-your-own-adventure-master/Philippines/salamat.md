Maligayang pasko at manigong bagong taon sa inyo! Salamat sa Udacity para sa

online class na ito :D

Ipagpatuloy ang adventure [dito] (bago/bago.md).

Un oh. Nakapag-tagalog din. [Pindot Kalikot] (bago/bago.md)

Buksan ang [pinto] (bagong simula/bagong_simula.md).

Pahinga muna sa pag-aaral. Manood ng [movie] (movie/movie.md)

Nakapag pahinga na. Salamat sa mga [pelikula] (movie/movie.md).
Ngayon ay ating sundan ang mga kaganapan sa Pilipinas. 
Kamakailan ay nanalong Presidente si [Duterte] (duterte/duterte.md).

O kung gusto mo namang kumain, tara [kain] (kain/kain.md) tayo !

Kinsay balo mag binisaya dinhi?

meow meow meow? [meow!](meow/meow.md)

Pwede rin pumindot dito kung gusto mo ng maikling [joke] (joke/joke.md)

Sumali sa usapan ng mga fan ni Bob Ong [Bob Ong] (bob-ong/bob-ong.md).
Alamin kung gaano mo kakilala ang iyong idolo.
Petsa: Nobyembre 17, 2016

Samahan si Benj sa kanyang paglalakbay! [Tara!](tara/tara.md)

Para sa mga gusto kumanta [kanta] (kanta/minsan.md)
Januart 12, 2017
