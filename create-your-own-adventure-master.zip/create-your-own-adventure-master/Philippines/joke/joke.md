Pare 1: anong hayop ang walang gilagid?
Pare 2: ano?
Pare 1: eh di langgam (lang-gums)
-acheche-