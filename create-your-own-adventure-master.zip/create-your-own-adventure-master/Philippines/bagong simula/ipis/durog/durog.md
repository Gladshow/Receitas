Napagdesisyunan mong durugin ang ipis ngunit habang papalapit ang iyong paa sa ipis
ay bumubuka naman ang likod nito, tila papalabas ang pakpak. Pumasok agad sayong isip na
lilipad ito at mag ttransform bilang si Ipis Man.

[Bilisan ang pag durog sa ipis](http://www.publicdomainpictures.net/pictures/60000/velka/cockroach.jpg).

[kumaripas palabas ng kwarto] (../../../salamat.md).