Nagdesisyon kang buksan ang pinto.
Inikot mo ang hawakan at itinulak paloob ang pinto hanggang magkaron ng puwang
para ika'y makadaan. Sa iyong pag-pasok, sinubukan mong hanapin ang pindutan ng
ilaw ngunit di mo ito makapa.

Ipagpatuloy maghanap ng [pindutan ng ilaw](ipis/ipis.md).

[Magsimula muli] (../salamat.md)

