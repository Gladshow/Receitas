Ito ang una mong hakbang tungo sa pagbabago.

Sa Mayo, bumoto. Bumoto ng wais.

*nang

Kahit anong gawin mo, magbabago ka.

Kung ayaw mo, bumalik sa Udacity para mag-aral o kaya bumalik sa [umpisa] (../../salamat.md)
