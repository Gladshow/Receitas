Dito nag-uumpisa ang iyong daan tungo sa pagbabago.

Isang [hakbang] (hakbang/hakbang.md) tungo sa pagbabago.

Bumalik sa Udacity para mag-aral o kaya bumalik sa [umpisa] (../salamat.md)
