Tumatak sa kasaysayan ng Pilipinas ang pagkapanalo ni Duterte bilang Pangulo
sa kadahilanang sya ang kauna unahang pangulo na galing Mindanao. Siya ay 
nailuklok sa pwesto noong June 30, 2016. 

Ayaw ko nang sundan ang kwento ni Duterte. [Lumabas] (../salamat.md)
