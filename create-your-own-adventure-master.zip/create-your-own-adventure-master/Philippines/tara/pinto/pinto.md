Binuksan ni Benj ang pinto. Binati siya ng makapal na hamog, at sinapak siya
nito. Sumigaw si Benj, "ang kapal mo, batang hamog!" Tumakbo papalayo ang batang
hamog dahil sa takot.
