Nagising si Benj sa isang kwarto. Nagmasid siya. Tanaw ang isang saradong pinto
sa kanyang harapan. Sa likod niya'y may isang bintanang salamin. May mga
nakakalat din na gamit sa loob ng kwarto.

[Buksan ang pinto.](pinto/pinto.md)

[Sumilip sa bintana.](bintana/bintana.md)

[Suriin ang mga gamit.](gamit/gamit.md)
