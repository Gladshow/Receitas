Sumilip si Benj sa bintana, subalit wala siyang makita dahil makapal ang hamog
sa labas. Binuksan niya ang bintana't sumigaw, "ang kapal mong batang hamog ka!
Hindi ko makita yung labas! Umalis ka riyan!" Sa takot ng batang hamog, tumakbo
siya papalayo.
