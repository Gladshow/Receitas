Sinuri ni Benj ang mga nakakalat na gamit. Para saan kaya ang mga gamit na ito?
Alamin sa susunod na kabanata.
