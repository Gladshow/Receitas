minsan sa may kalayaan tayo'y nagkatagpuan
may mga sariling gimik at kanya-kanyang hangad sa buhay