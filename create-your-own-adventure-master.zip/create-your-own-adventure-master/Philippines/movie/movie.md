Mamili:

Manood ng captain america.

Manood ng avengers.

Nagbago ng isip at bumalik sa [choices] (../salamat.md).