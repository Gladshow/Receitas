Podíváš se po kapsách a najdeš jeden zapalovač, žvýkačky, a 666 Kč.

Celé je to nějaké podivné. Proč máš v kapse zapalovač?

Vždyť kouřit jsi přestal v jedenácti a na žvýkačky máš alergii, jediné co sneseš je žvýkací tabák.

Že by to byl sen? Rozhodneš se otestovat tuhle údajnou realitu.

["Štípneš" se nožem?](nuz/riz.md)

[Roztočíš minci jak ve filmu Inception?](mince/roztocit.md)
