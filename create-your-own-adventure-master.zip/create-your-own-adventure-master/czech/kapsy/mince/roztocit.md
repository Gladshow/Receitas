Zmuchlanou šestistovku a šedesátikorunu vrátíš zpět do kapsy.

Na zemi roztočíš šestikorunu. Ta se točí, točí, točí ...

Až se zastaví o kousek maršmelounu, který se odlepil od stropu podivné místnosti.

Když chceš zjistit zda padl rub nebo líc s překvapením zjistíš, že to nebyla normální
šestikoruna, ale na lícní straně je vyryta podobizna šklebícího se ďábla.
