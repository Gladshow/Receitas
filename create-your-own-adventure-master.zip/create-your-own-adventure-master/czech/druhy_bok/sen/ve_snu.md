Ve spánku jsis uvědomil sám sebe a pokusil jsi se usnout. To se ti povedlo. Zdá se ti sen.
Sníš sen o snu ve snu.

