Jako typickej Čech sedíš a čumíš. Otevíráš pivo a zapínáš televizi.
Z ní už je slyšet jenom: "... pasy, pane redaktore, víte co to v angličtině znamená?
To je kunda!"
