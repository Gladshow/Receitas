Jednoho rána se vzbudíš v divné místnosti se zdmi z maršmelounů.

Co uděláš:

[Nic?](nic/typickej-cech.md)

[Zkusíš prohledat kapsy?](kapsy/prohledat.md)

[Řekneš si, že s tím alkoholem už opravdu končíš, překulíš se na druhý bok a usneš](druhy_bok/spanek.md)

[Uděláš zřejmé](zrejme/udelas.md)