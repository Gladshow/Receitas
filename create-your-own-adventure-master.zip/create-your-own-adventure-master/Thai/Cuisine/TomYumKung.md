If you want to have the taste of Thai food, you must try Tom Yum Kung.

It is chilli paste mixed with soup. The word Kung meant shrimp!!!

I had Thai food once and it was hot!

Please try to taste Tom Yum Kung when you found Thai restaurant around you.

You may also want to try Kang-kiew-wan.
Do you:

[eat Thai food with Japanese beer](../../japanese/beer/beer.md)

[sing a song while having Thai food](../../english/sing-song/sing.md)

[ดูทีวี eat Thai food and watch TV](https://www.youtube.com)

[I will fly to Thailand to have it there](../travel.md)

Actually I prefer Thai Green Curry better!
